#!c:\users\user\desktop\coding~1\assign~1\projects\tutori~1\portfo~1\myvenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
